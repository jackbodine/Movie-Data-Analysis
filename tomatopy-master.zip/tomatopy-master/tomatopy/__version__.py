"""__version__.py

Versioning only.

This file contains not functions.

"""
__version__ = '0.1.0'